﻿. Pour générer l'exécutable, lancer le script build.bat en veillant a bien intégrer le MANIFEST.MF fourni.

. Temps d'exécution trouvé avant heuristique :
	. 5x5 : 58 ms
	. 6x6 : 384 ms
	. 7x7 : 150 ms
	. visuellement, 8x8 : environ une minute 
	. visuellement, 9x9 : ??
	. visuellement, 10x10 : ??

. Temps d'exécution trouvé après heuristique :
	. 5x5 : 19 ms
	. 6x6 : 44 ms
	. 7x7 : 589 ms
	. 8x8 : 125 ms
	. 9x9 : 44 ms
	. 10x10 : 392 ms
	. 11x11 : 54 ms
	. 12x12 : 


