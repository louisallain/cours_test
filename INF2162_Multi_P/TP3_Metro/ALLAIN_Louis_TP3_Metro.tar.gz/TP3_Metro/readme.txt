﻿. Dans mon TP2, j'avais utilisé une librairie externe pour gérer le graphe de la classe Reseau. Dans ce TP3 je corrige, en implémentant
  un graphe moi-même.

. Proc�dure pour g�n�rer � nouveau le jar ex�cutable de mon TP3 :
	1. En se positionnant dans le r�pertoire racine (o� il y a le readme.txt), compiler les sources : javac ./src/metro/*.java -d .
	2. Cr�er l'ex�cutable : jar cvfm metro.jar MANIFEST.MF metro res

. Pour lancer le r�sultat de mon TP2 :
	1. Ouvrir un terminal et taper java -jar Allain_Louis_Metro.jar


