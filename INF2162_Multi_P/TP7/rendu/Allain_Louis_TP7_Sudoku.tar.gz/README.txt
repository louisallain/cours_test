Cette archive contient le TP7-Sudoku de Louis Allain.
L'exécution du jar produit par défaut des résultats montrant à la console :
1. Une grille complète générée par le programme
2. Une grille de sudoku aléatoire avec 17 indices par exemple
3. La grille précédente solutionnée grâce au programme

Pour exécuter le jar : 

./launch.sh
ou
scala Allain_Louis_TP7_Sudoku.jar