Cette archive contient le TP8-Sudoku/Anagramme de Louis Allain.
L'exécution du jar produit par défaut des résultats montrant à la console :
1. La grille de sudoku donnée dans le TP résolue par mon programme (parcours_12)
2. Trois exemples de permutations des lettres d'un mot (longueur 3, longueur 4 et longueur 5)

Pour exécuter le jar : 

./launch.sh