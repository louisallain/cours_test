- Le nombre d'itérations est fixés à 10 000 dans tous les cas.
- L'exécution de l'application montre le fonctionnement du perceptron 
avec le XOR, le AND et le OR.