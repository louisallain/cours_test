package louis.inf2165.banque;

/**
 * Cette énumération définie tous les types d'opérations possibles.
 */
public enum TypeOperation {
    RETRAIT,
    DEPOT
}