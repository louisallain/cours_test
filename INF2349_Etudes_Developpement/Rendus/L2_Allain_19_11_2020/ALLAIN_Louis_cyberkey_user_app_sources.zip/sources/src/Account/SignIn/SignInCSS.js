import { StyleSheet } from "react-native";

export default StyleSheet.create({

    header: {
        backgroundColor: "#4285F4",
    },
    createButton: {
        backgroundColor: "#4285F4",
        margin: 30,
        bottom: 0,
    },
    createButtonDisabled: {
        backgroundColor: "grey",
        margin: 30,
        bottom: 0,
    },
})