export const ACCOUNT_SIGN_IN= "account_sign_in"
export const ACCOUNT_LOG_IN=  "account_log_in"
export const HOME=  "home"