import { StyleSheet } from "react-native";

export default StyleSheet.create({

    header: {
        backgroundColor: "#4285F4",
    },
    segment: {
        backgroundColor: "#4285F4",
    },
    settingsTab: {
        backgroundColor: "white",
    }
})