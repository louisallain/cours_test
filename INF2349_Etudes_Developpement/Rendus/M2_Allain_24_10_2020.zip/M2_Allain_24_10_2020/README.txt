# Le lien de l'application se trouve dans le fichier "lien_application_admin.txt".

# Les sources documentées se trouvent dans l'archive "cyberkey_admin_app_source.zip".

# De la documentation générale sur les fonctionnalités de l'application se trouve dans le fichier "CyberKey_AdminApp_utilisation.pdf"