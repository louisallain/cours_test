- Tests :
   - Lancer le moniteur avec le script launch_moniteur.sh
   - Lancer le capteur avec le script launch_capteur.sh

- La période de détection du capteur est la suivante : 5 ; 30 ; 10 ; 40